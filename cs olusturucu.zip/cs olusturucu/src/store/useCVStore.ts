import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CVData, Experience, Education, SkillCategory, Project, Language, Certification } from '../types/cv';
import { v4 as uuidv4 } from 'uuid';

interface CVState {
  cvData: CVData;
  updatePersonalInfo: (data: Partial<CVData['personalInfo']>) => void;
  updateSummary: (summary: string) => void;
  
  // Experience
  updateExperience: (id: string, data: Partial<Experience>) => void;
  addExperience: () => void;
  removeExperience: (id: string) => void;
  reorderExperience: (startIndex: number, endIndex: number) => void;
  
  // Education
  updateEducation: (id: string, data: Partial<Education>) => void;
  addEducation: () => void;
  removeEducation: (id: string) => void;
  reorderEducation: (startIndex: number, endIndex: number) => void;

  // Skills
  updateSkillCategory: (id: string, data: Partial<SkillCategory>) => void;
  addSkillCategory: () => void;
  removeSkillCategory: (id: string) => void;
  reorderSkillCategory: (startIndex: number, endIndex: number) => void;

  // Projects
  updateProject: (id: string, data: Partial<Project>) => void;
  addProject: () => void;
  removeProject: (id: string) => void;
  reorderProject: (startIndex: number, endIndex: number) => void;

  // Languages
  updateLanguage: (id: string, data: Partial<Language>) => void;
  addLanguage: () => void;
  removeLanguage: (id: string) => void;
  reorderLanguage: (startIndex: number, endIndex: number) => void;

  // Certifications
  updateCertification: (id: string, data: Partial<Certification>) => void;
  addCertification: () => void;
  removeCertification: (id: string) => void;
  reorderCertification: (startIndex: number, endIndex: number) => void;
}

const initialData: CVData = {
  personalInfo: {
    firstName: 'Ahmet',
    lastName: 'Yılmaz',
    title: 'Kıdemli Yazılım Mühendisi',
    email: 'ahmet.yilmaz@email.com',
    phone: '+90 555 123 4567',
    location: 'İstanbul, Türkiye',
    linkedin: 'linkedin.com/in/ahmetyilmaz',
    github: 'github.com/ahmetyilmaz'
  },
  summary: 'Yüksek ölçeklenebilir web uygulamaları geliştirme konusunda 5+ yıl deneyimli yazılım mühendisi. Mikroservis mimarileri ve performans optimizasyonu konularında uzman.',
  experience: [
    {
      id: uuidv4(),
      company: 'Tech Corp',
      position: 'Backend Developer',
      startDate: '2020-01',
      endDate: '2023-12',
      isCurrent: false,
      location: 'İstanbul',
      description: [
        'Veritabanı sorgularını optimize ederek ve Redis caching mekanizması entegre ederek sayfa yüklenme hızını %40 artırdım; bu sayede kullanıcı kaybını azalttım; bu işlemleri Node.js ve PostgreSQL kullanarak gerçekleştirdim.'
      ]
    }
  ],
  education: [
    {
      id: uuidv4(),
      institution: 'İstanbul Teknik Üniversitesi',
      degree: 'Lisans',
      field: 'Bilgisayar Mühendisliği',
      startDate: '2015-09',
      endDate: '2019-06',
      isCurrent: false,
      gpa: '3.50'
    }
  ],
  skills: [
    {
      id: uuidv4(),
      name: 'Prog. Dilleri',
      skills: ['JavaScript', 'TypeScript', 'Go']
    },
    {
      id: uuidv4(),
      name: 'Frameworks/Libraries',
      skills: ['React', 'Next.js', 'Node.js']
    }
  ],
  projects: [
    {
      id: uuidv4(),
      name: 'E-Ticaret Platformu',
      purpose: 'Yüksek trafikli alışveriş sitesi',
      techStack: 'Next.js, Node.js, PostgreSQL',
      challenge: 'Anlık 10k kullanıcıyı kaldıracak sepet mimarisi tasarımı.',
      link: 'github.com/ahmetyilmaz/e-commerce'
    }
  ],
  languages: [
    {
      id: uuidv4(),
      name: 'İngilizce',
      level: 'Profesyonel Çalışma Yetkinliği'
    }
  ],
  certifications: [
    {
      id: uuidv4(),
      name: 'AWS Certified Solutions Architect',
      issuer: 'Amazon Web Services',
      date: '2023-05'
    }
  ]
};

export const useCVStore = create<CVState>()(
  persist(
    (set) => ({
      cvData: initialData,
      
      updatePersonalInfo: (data) =>
        set((state) => ({ cvData: { ...state.cvData, personalInfo: { ...state.cvData.personalInfo, ...data } } })),
      
      updateSummary: (summary) =>
        set((state) => ({ cvData: { ...state.cvData, summary } })),

      // Experience
      updateExperience: (id, data) =>
        set((state) => ({
          cvData: { ...state.cvData, experience: state.cvData.experience.map(item => item.id === id ? { ...item, ...data } : item) },
        })),
      addExperience: () =>
        set((state) => ({
          cvData: {
            ...state.cvData,
            experience: [...state.cvData.experience, { id: uuidv4(), company: '', position: '', startDate: '', endDate: '', isCurrent: false, description: [''] }]
          },
        })),
      removeExperience: (id) =>
        set((state) => ({ cvData: { ...state.cvData, experience: state.cvData.experience.filter(item => item.id !== id) } })),
      reorderExperience: (startIndex, endIndex) =>
        set((state) => {
          const result = Array.from(state.cvData.experience);
          const [removed] = result.splice(startIndex, 1);
          result.splice(endIndex, 0, removed);
          return { cvData: { ...state.cvData, experience: result } };
        }),

      // Education
      updateEducation: (id, data) =>
        set((state) => ({
          cvData: { ...state.cvData, education: state.cvData.education.map(item => item.id === id ? { ...item, ...data } : item) },
        })),
      addEducation: () =>
        set((state) => ({
          cvData: {
            ...state.cvData,
            education: [...state.cvData.education, { id: uuidv4(), institution: '', degree: '', field: '', startDate: '', endDate: '', isCurrent: false }]
          },
        })),
      removeEducation: (id) =>
        set((state) => ({ cvData: { ...state.cvData, education: state.cvData.education.filter(item => item.id !== id) } })),
      reorderEducation: (startIndex, endIndex) =>
        set((state) => {
          const result = Array.from(state.cvData.education);
          const [removed] = result.splice(startIndex, 1);
          result.splice(endIndex, 0, removed);
          return { cvData: { ...state.cvData, education: result } };
        }),

      // Skills
      updateSkillCategory: (id, data) =>
        set((state) => ({
          cvData: { ...state.cvData, skills: state.cvData.skills.map(item => item.id === id ? { ...item, ...data } : item) },
        })),
      addSkillCategory: () =>
        set((state) => ({
          cvData: {
            ...state.cvData,
            skills: [...state.cvData.skills, { id: uuidv4(), name: '', skills: [] }]
          },
        })),
      removeSkillCategory: (id) =>
        set((state) => ({ cvData: { ...state.cvData, skills: state.cvData.skills.filter(item => item.id !== id) } })),
      reorderSkillCategory: (startIndex, endIndex) =>
        set((state) => {
          const result = Array.from(state.cvData.skills);
          const [removed] = result.splice(startIndex, 1);
          result.splice(endIndex, 0, removed);
          return { cvData: { ...state.cvData, skills: result } };
        }),

      // Projects
      updateProject: (id, data) =>
        set((state) => ({
          cvData: { ...state.cvData, projects: state.cvData.projects.map(item => item.id === id ? { ...item, ...data } : item) },
        })),
      addProject: () =>
        set((state) => ({
          cvData: {
            ...state.cvData,
            projects: [...state.cvData.projects, { id: uuidv4(), name: '', purpose: '', techStack: '', challenge: '' }]
          },
        })),
      removeProject: (id) =>
        set((state) => ({ cvData: { ...state.cvData, projects: state.cvData.projects.filter(item => item.id !== id) } })),
      reorderProject: (startIndex, endIndex) =>
        set((state) => {
          const result = Array.from(state.cvData.projects);
          const [removed] = result.splice(startIndex, 1);
          result.splice(endIndex, 0, removed);
          return { cvData: { ...state.cvData, projects: result } };
        }),

      // Languages
      updateLanguage: (id, data) =>
        set((state) => ({
          cvData: { ...state.cvData, languages: state.cvData.languages.map(item => item.id === id ? { ...item, ...data } : item) },
        })),
      addLanguage: () =>
        set((state) => ({
          cvData: {
            ...state.cvData,
            languages: [...state.cvData.languages, { id: uuidv4(), name: '', level: '' }]
          },
        })),
      removeLanguage: (id) =>
        set((state) => ({ cvData: { ...state.cvData, languages: state.cvData.languages.filter(item => item.id !== id) } })),
      reorderLanguage: (startIndex, endIndex) =>
        set((state) => {
          const result = Array.from(state.cvData.languages);
          const [removed] = result.splice(startIndex, 1);
          result.splice(endIndex, 0, removed);
          return { cvData: { ...state.cvData, languages: result } };
        }),

      // Certifications
      updateCertification: (id, data) =>
        set((state) => ({
          cvData: { ...state.cvData, certifications: state.cvData.certifications.map(item => item.id === id ? { ...item, ...data } : item) },
        })),
      addCertification: () =>
        set((state) => ({
          cvData: {
            ...state.cvData,
            certifications: [...state.cvData.certifications, { id: uuidv4(), name: '', issuer: '', date: '' }]
          },
        })),
      removeCertification: (id) =>
        set((state) => ({ cvData: { ...state.cvData, certifications: state.cvData.certifications.filter(item => item.id !== id) } })),
      reorderCertification: (startIndex, endIndex) =>
        set((state) => {
          const result = Array.from(state.cvData.certifications);
          const [removed] = result.splice(startIndex, 1);
          result.splice(endIndex, 0, removed);
          return { cvData: { ...state.cvData, certifications: result } };
        }),
    }),
    {
      name: 'cv-storage',
    }
  )
);
