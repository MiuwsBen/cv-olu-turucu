'use client';

import { useRef, useState, useEffect } from 'react';
import { useReactToPrint } from 'react-to-print';
import { Printer } from 'lucide-react';
import { useCVStore } from '@/store/useCVStore';
import { PersonalInfoForm } from '@/components/cv-form/PersonalInfoForm';
import { ExperienceForm } from '@/components/cv-form/ExperienceForm';
import { EducationForm } from '@/components/cv-form/EducationForm';
import { SkillsForm } from '@/components/cv-form/SkillsForm';
import { ProjectsForm } from '@/components/cv-form/ProjectsForm';
import { LanguagesForm } from '@/components/cv-form/LanguagesForm';
import { CertificationsForm } from '@/components/cv-form/CertificationsForm';

const CVForm = () => {
  return (
    <div className="p-6 space-y-8 pb-32">
      <PersonalInfoForm />
      <ExperienceForm />
      <EducationForm />
      <SkillsForm />
      <ProjectsForm />
      <LanguagesForm />
      <CertificationsForm />
    </div>
  );
};

const CVPreview = ({ innerRef }: { innerRef: React.RefObject<HTMLDivElement | null> }) => {
  const { cvData } = useCVStore();
  const { personalInfo, summary, experience, education, skills, projects, languages, certifications } = cvData;

  const contactItems = [
    personalInfo.email,
    personalInfo.phone,
    personalInfo.location,
    personalInfo.linkedin && (
      <a key="li" href={`https://${personalInfo.linkedin}`} className="text-indigo-800 hover:text-indigo-950 transition-colors">
        {personalInfo.linkedin.replace('linkedin.com/in/', '')}
      </a>
    ),
    personalInfo.github && (
      <a key="gh" href={`https://${personalInfo.github}`} className="text-indigo-800 hover:text-indigo-950 transition-colors">
        {personalInfo.github.replace('github.com/', '')}
      </a>
    ),
    personalInfo.website && (
      <a key="web" href={`https://${personalInfo.website}`} className="text-indigo-800 hover:text-indigo-950 transition-colors">
        {personalInfo.website}
      </a>
    ),
    personalInfo.militaryService && (
      <span key="military">Askerlik: {personalInfo.militaryService}</span>
    ),
    personalInfo.drivingLicense && (
      <span key="license">Ehliyet: {personalInfo.drivingLicense}</span>
    )
  ].filter(Boolean);

  return (
    <div 
      ref={innerRef} 
      className="bg-white p-8 md:p-10 border border-slate-200 min-h-[1056px] w-full max-w-[816px] mx-auto print:border-none print:p-0 print:max-w-none print:min-h-0"
    >
      {/* Header */}
      <header className="mb-4 border-b-2 border-slate-800 pb-3">
        <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 uppercase mb-1">
          {personalInfo.firstName} {personalInfo.lastName}
        </h1>
        <p className="text-xl font-medium text-indigo-900 mb-2">{personalInfo.title}</p>
        
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-slate-600 font-medium">
          {contactItems.map((item, index) => (
            <div key={index} className="flex items-center">
              {item}
              {index < contactItems.length - 1 && (
                <span className="mx-3 text-slate-300">|</span>
              )}
            </div>
          ))}
        </div>
      </header>

      {/* Summary */}
      {summary && (
        <section className="mb-4">
          <p className="text-sm text-slate-700 leading-snug font-medium">
            {summary}
          </p>
        </section>
      )}

      {/* Experience */}
      {experience.length > 0 && (
        <section className="mb-4">
          <h2 className="text-lg font-bold uppercase tracking-widest text-slate-900 border-b border-slate-300 pb-1 mb-2">
            İş Deneyimi
          </h2>
          <div className="space-y-3">
            {experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-baseline mb-0.5">
                  <h3 className="text-base font-bold text-slate-900">{exp.position}</h3>
                  <span className="text-sm text-slate-500 font-semibold tracking-wide whitespace-nowrap ml-4">
                    {exp.startDate} — {exp.isCurrent ? 'Devam Ediyor' : exp.endDate}
                  </span>
                </div>
                <div className="text-sm font-semibold text-indigo-900 mb-1.5">
                  {exp.company}{exp.location ? `, ${exp.location}` : ''}
                </div>
                {exp.description.length > 0 && exp.description[0] !== '' && (
                  <ul className="list-none space-y-1">
                    {exp.description.map((desc, index) => desc && (
                      <li key={index} className="text-sm text-slate-700 leading-snug border-l-2 border-indigo-200 pl-3">
                        {desc}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Projects */}
      {projects.length > 0 && (
        <section className="mb-4">
          <h2 className="text-lg font-bold uppercase tracking-widest text-slate-900 border-b border-slate-300 pb-1 mb-2">
            Projeler
          </h2>
          <div className="space-y-3">
            {projects.map((project) => (
              <div key={project.id}>
                <div className="flex justify-between items-baseline mb-0.5">
                  <h3 className="text-base font-bold text-slate-900">
                    {project.name} 
                    {project.link && (
                      <a href={`https://${project.link}`} className="text-sm font-medium text-indigo-700 hover:text-indigo-900 ml-2">
                        ({project.link.replace(/^https?:\/\//, '')})
                      </a>
                    )}
                  </h3>
                </div>
                <div className="text-sm font-semibold text-slate-600 mb-1">
                  <span className="text-indigo-900">Teknolojiler:</span> {project.techStack}
                </div>
                <div className="text-sm text-slate-700 leading-snug space-y-1 border-l-2 border-indigo-200 pl-3">
                  {project.purpose && <p>{project.purpose}</p>}
                  {project.challenge && <p><span className="font-semibold text-slate-900">Katkı & Zorluk:</span> {project.challenge}</p>}
                  {project.systemDesign && <p><span className="font-semibold text-slate-900">Sistem Mimarisi:</span> {project.systemDesign}</p>}
                  {project.scalability && <p><span className="font-semibold text-slate-900">Ölçeklenebilirlik:</span> {project.scalability}</p>}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Skills */}
      {skills.length > 0 && (
        <section className="mb-4">
          <h2 className="text-lg font-bold uppercase tracking-widest text-slate-900 border-b border-slate-300 pb-1 mb-2">
            Yetenekler & Teknolojiler
          </h2>
          <div className="grid grid-cols-1 gap-1.5">
            {skills.map((category) => (
              <div key={category.id} className="text-sm flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-2">
                <span className="font-bold text-slate-900 sm:w-40 shrink-0">{category.name}</span>
                <span className="text-slate-700 leading-snug">{category.skills.join(', ')}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Education */}
      {education.length > 0 && (
        <section className="mb-4">
          <h2 className="text-lg font-bold uppercase tracking-widest text-slate-900 border-b border-slate-300 pb-1 mb-2">
            Eğitim
          </h2>
          <div className="space-y-3">
            {education.map((edu) => (
              <div key={edu.id}>
                <div className="flex justify-between items-baseline mb-0.5">
                  <h3 className="text-base font-bold text-slate-900">{edu.institution}</h3>
                  <span className="text-sm text-slate-500 font-semibold tracking-wide whitespace-nowrap ml-4">
                    {edu.startDate} — {edu.isCurrent ? 'Devam Ediyor' : edu.endDate}
                  </span>
                </div>
                <div className="text-sm font-medium text-slate-700">
                  {edu.degree} - {edu.field} {edu.gpa && <span className="font-bold text-indigo-900 ml-2">GPA: {edu.gpa}</span>}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <div className="grid grid-cols-2 gap-6">
        {/* Languages */}
        {languages.length > 0 && (
          <section className="mb-4">
            <h2 className="text-lg font-bold uppercase tracking-widest text-slate-900 border-b border-slate-300 pb-1 mb-2">
              Diller
            </h2>
            <div className="space-y-1">
              {languages.map((lang) => (
                <div key={lang.id} className="text-sm flex justify-between border-b border-slate-100 pb-1 last:border-0">
                  <span className="font-bold text-slate-900">{lang.name}</span>
                  <span className="text-slate-600 font-medium">{lang.level}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Certifications */}
        {certifications.length > 0 && (
          <section className="mb-4">
            <h2 className="text-lg font-bold uppercase tracking-widest text-slate-900 border-b border-slate-300 pb-1 mb-2">
              Sertifikalar
            </h2>
            <div className="space-y-1.5">
              {certifications.map((cert) => (
                <div key={cert.id} className="text-sm leading-snug">
                  <div className="font-bold text-slate-900">{cert.name}</div>
                  <div className="text-slate-600">
                    {cert.issuer} {cert.date && <span className="text-slate-400 mx-1">•</span>} {cert.date}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

export default function Home() {
  const contentRef = useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = useState(false);
  
  const reactToPrintFn = useReactToPrint({ 
    contentRef,
    documentTitle: "CV",
  });

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    // Prevent hydration mismatch by returning a loading placeholder or null until mounted
    return <div className="h-screen bg-slate-100 flex items-center justify-center">Yükleniyor...</div>;
  }

  return (
    <div className="h-screen flex flex-col md:flex-row overflow-hidden bg-slate-100">
      {/* Left Sidebar - Form */}
      <div className="w-full md:w-1/2 lg:w-[45%] h-full overflow-y-auto border-r border-slate-200 bg-white z-10 relative">
        <div className="sticky top-0 z-20 bg-white border-b border-slate-200 p-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-slate-900">CV Oluşturucu</h1>
          <button 
            onClick={() => reactToPrintFn()}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-md text-sm font-medium transition-colors"
          >
            <Printer size={16} />
            <span>PDF İndir</span>
          </button>
        </div>
        <CVForm />
      </div>

      {/* Right Content - Preview */}
      <div className="w-full md:w-1/2 lg:w-[55%] h-full overflow-y-auto bg-slate-100 p-4 md:p-8 flex justify-center items-start">
        <CVPreview innerRef={contentRef} />
      </div>
    </div>
  );
}
