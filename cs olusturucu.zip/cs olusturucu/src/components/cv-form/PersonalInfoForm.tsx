'use client';

import { useCVStore } from '@/store/useCVStore';

export const PersonalInfoForm = () => {
  const { cvData, updatePersonalInfo, updateSummary } = useCVStore();
  const info = cvData.personalInfo;

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-indigo-900 border-b border-slate-200 pb-2">Kişisel Bilgiler</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700">Ad</label>
            <input 
              type="text" 
              value={info.firstName}
              onChange={(e) => updatePersonalInfo({ firstName: e.target.value })}
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Soyad</label>
            <input 
              type="text" 
              value={info.lastName}
              onChange={(e) => updatePersonalInfo({ lastName: e.target.value })}
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-slate-700">Unvan / Meslek Başlığı</label>
            <input 
              type="text" 
              value={info.title}
              onChange={(e) => updatePersonalInfo({ title: e.target.value })}
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">E-posta</label>
            <input 
              type="email" 
              value={info.email}
              onChange={(e) => updatePersonalInfo({ email: e.target.value })}
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Telefon</label>
            <input 
              type="text" 
              value={info.phone}
              onChange={(e) => updatePersonalInfo({ phone: e.target.value })}
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Konum (Şehir, Ülke)</label>
            <input 
              type="text" 
              value={info.location}
              onChange={(e) => updatePersonalInfo({ location: e.target.value })}
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">LinkedIn</label>
            <input 
              type="text" 
              value={info.linkedin || ''}
              onChange={(e) => updatePersonalInfo({ linkedin: e.target.value })}
              placeholder="linkedin.com/in/..."
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">GitHub</label>
            <input 
              type="text" 
              value={info.github || ''}
              onChange={(e) => updatePersonalInfo({ github: e.target.value })}
              placeholder="github.com/..."
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Website</label>
            <input 
              type="text" 
              value={info.website || ''}
              onChange={(e) => updatePersonalInfo({ website: e.target.value })}
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Askerlik Durumu</label>
            <input 
              type="text" 
              value={info.militaryService || ''}
              onChange={(e) => updatePersonalInfo({ militaryService: e.target.value })}
              placeholder="Örn: Tecilli (2028), Yapıldı, Muaf"
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Ehliyet</label>
            <input 
              type="text" 
              value={info.drivingLicense || ''}
              onChange={(e) => updatePersonalInfo({ drivingLicense: e.target.value })}
              placeholder="Örn: B Sınıfı"
              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-indigo-900 border-b border-slate-200 pb-2">Profil Özeti</h3>
        <div>
          <textarea 
            value={cvData.summary}
            onChange={(e) => updateSummary(e.target.value)}
            rows={4}
            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border"
            placeholder="Kendinizi 3-4 cümlede özetleyin..."
          />
        </div>
      </div>
    </div>
  );
};
