'use client';

import { useCVStore } from '@/store/useCVStore';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import { GripVertical, Plus, Trash2 } from 'lucide-react';

export const ExperienceForm = () => {
  const { cvData, updateExperience, addExperience, removeExperience, reorderExperience } = useCVStore();

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    reorderExperience(result.source.index, result.destination.index);
  };

  const handleDescriptionChange = (expId: string, index: number, value: string) => {
    const exp = cvData.experience.find(e => e.id === expId);
    if (exp) {
      const newDesc = [...exp.description];
      newDesc[index] = value;
      updateExperience(expId, { description: newDesc });
    }
  };

  const addDescriptionBullet = (expId: string) => {
    const exp = cvData.experience.find(e => e.id === expId);
    if (exp) {
      updateExperience(expId, { description: [...exp.description, ''] });
    }
  };

  const removeDescriptionBullet = (expId: string, index: number) => {
    const exp = cvData.experience.find(e => e.id === expId);
    if (exp) {
      const newDesc = exp.description.filter((_, i) => i !== index);
      updateExperience(expId, { description: newDesc });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center border-b border-slate-200 pb-2">
        <h3 className="text-lg font-semibold text-indigo-900">İş Deneyimi</h3>
        <button 
          onClick={addExperience}
          className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 font-medium"
        >
          <Plus size={16} /> Ekle
        </button>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="experience-list">
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
              {cvData.experience.map((exp, index) => (
                <Draggable key={exp.id} draggableId={exp.id} index={index}>
                  {(provided) => (
                    <div 
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className="border border-slate-200 rounded-md p-4 bg-slate-50 relative group"
                    >
                      <div 
                        {...provided.dragHandleProps} 
                        className="absolute left-2 top-4 text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing"
                      >
                        <GripVertical size={20} />
                      </div>
                      
                      <button 
                        onClick={() => removeExperience(exp.id)}
                        className="absolute right-2 top-4 text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Sil"
                      >
                        <Trash2 size={18} />
                      </button>

                      <div className="pl-6 space-y-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-medium text-slate-700">Şirket Adı</label>
                            <input 
                              type="text" value={exp.company}
                              onChange={(e) => updateExperience(exp.id, { company: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-700">Pozisyon / Unvan</label>
                            <input 
                              type="text" value={exp.position}
                              onChange={(e) => updateExperience(exp.id, { position: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-700">Başlangıç (Örn: 2020-01)</label>
                            <input 
                              type="text" value={exp.startDate}
                              onChange={(e) => updateExperience(exp.id, { startDate: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                          <div>
                            <div className="flex justify-between items-center">
                              <label className="block text-xs font-medium text-slate-700">Bitiş</label>
                              <label className="flex items-center text-xs text-indigo-700 cursor-pointer">
                                <input 
                                  type="checkbox" 
                                  checked={exp.isCurrent}
                                  onChange={(e) => updateExperience(exp.id, { isCurrent: e.target.checked })}
                                  className="mr-1 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                                />
                                Devam Ediyor
                              </label>
                            </div>
                            <input 
                              type="text" value={exp.endDate}
                              disabled={exp.isCurrent}
                              onChange={(e) => updateExperience(exp.id, { endDate: e.target.value })}
                              className={`mt-1 block w-full rounded-md border-slate-300 shadow-sm sm:text-sm p-1.5 border ${exp.isCurrent ? 'bg-slate-100 text-slate-400' : 'focus:border-indigo-500 focus:ring-indigo-500'}`}
                            />
                          </div>
                          <div className="md:col-span-2">
                            <label className="block text-xs font-medium text-slate-700">Konum (Opsiyonel)</label>
                            <input 
                              type="text" value={exp.location || ''}
                              onChange={(e) => updateExperience(exp.id, { location: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <label className="block text-xs font-medium text-slate-700">Görev ve Başarılar (XYZ Formülü Önerilir)</label>
                            <button disabled className="text-[10px] font-medium text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded cursor-not-allowed">
                              ✨ AI ile Güzelleştir (Yakında)
                            </button>
                          </div>
                          <div className="space-y-2">
                            {exp.description.map((desc, i) => (
                              <div key={i} className="flex gap-2 items-start">
                                <span className="text-slate-400 mt-2">•</span>
                                <textarea
                                  value={desc}
                                  onChange={(e) => handleDescriptionChange(exp.id, i, e.target.value)}
                                  className="block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border min-h-[60px]"
                                  placeholder="Örn: X başardım, Y ölçülebilir kriteri ile, Z teknolojisini kullanarak..."
                                />
                                <button 
                                  onClick={() => removeDescriptionBullet(exp.id, i)}
                                  className="mt-2 text-slate-400 hover:text-red-500"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </div>
                            ))}
                            <button 
                              onClick={() => addDescriptionBullet(exp.id)}
                              className="text-xs text-indigo-600 hover:text-indigo-800 flex items-center gap-1 mt-1"
                            >
                              <Plus size={14} /> Madde Ekle
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
};
