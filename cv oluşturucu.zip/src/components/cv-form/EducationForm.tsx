'use client';

import { useCVStore } from '@/store/useCVStore';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import { GripVertical, Plus, Trash2 } from 'lucide-react';

export const EducationForm = () => {
  const { cvData, updateEducation, addEducation, removeEducation, reorderEducation } = useCVStore();

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    reorderEducation(result.source.index, result.destination.index);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center border-b border-slate-200 pb-2">
        <h3 className="text-lg font-semibold text-indigo-900">Eğitim</h3>
        <button 
          onClick={addEducation}
          className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 font-medium"
        >
          <Plus size={16} /> Ekle
        </button>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="education-list">
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
              {cvData.education.map((edu, index) => (
                <Draggable key={edu.id} draggableId={edu.id} index={index}>
                  {(provided) => (
                    <div 
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className="border border-slate-200 rounded-md p-4 bg-slate-50 relative group"
                    >
                      <div 
                        {...provided.dragHandleProps} 
                        className="absolute left-2 top-4 text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing"
                      >
                        <GripVertical size={20} />
                      </div>
                      
                      <button 
                        onClick={() => removeEducation(edu.id)}
                        className="absolute right-2 top-4 text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Sil"
                      >
                        <Trash2 size={18} />
                      </button>

                      <div className="pl-6 grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="md:col-span-2">
                          <label className="block text-xs font-medium text-slate-700">Okul / Üniversite Adı</label>
                          <input 
                            type="text" value={edu.institution}
                            onChange={(e) => updateEducation(edu.id, { institution: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700">Derece (Örn: Lisans, YL)</label>
                          <input 
                            type="text" value={edu.degree}
                            onChange={(e) => updateEducation(edu.id, { degree: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700">Bölüm / Fakülte</label>
                          <input 
                            type="text" value={edu.field}
                            onChange={(e) => updateEducation(edu.id, { field: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700">Başlangıç</label>
                          <input 
                            type="text" value={edu.startDate}
                            onChange={(e) => updateEducation(edu.id, { startDate: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                          />
                        </div>
                        <div>
                          <div className="flex justify-between items-center">
                            <label className="block text-xs font-medium text-slate-700">Bitiş</label>
                            <label className="flex items-center text-xs text-indigo-700 cursor-pointer">
                              <input 
                                type="checkbox" 
                                checked={edu.isCurrent}
                                onChange={(e) => updateEducation(edu.id, { isCurrent: e.target.checked })}
                                className="mr-1 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                              />
                              Devam Ediyor
                            </label>
                          </div>
                          <input 
                            type="text" value={edu.endDate}
                            disabled={edu.isCurrent}
                            onChange={(e) => updateEducation(edu.id, { endDate: e.target.value })}
                            className={`mt-1 block w-full rounded-md border-slate-300 shadow-sm sm:text-sm p-1.5 border ${edu.isCurrent ? 'bg-slate-100 text-slate-400' : 'focus:border-indigo-500 focus:ring-indigo-500'}`}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700">GPA (Opsiyonel)</label>
                          <input 
                            type="text" value={edu.gpa || ''}
                            onChange={(e) => updateEducation(edu.id, { gpa: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
};
