'use client';

import { useCVStore } from '@/store/useCVStore';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import { GripVertical, Plus, Trash2 } from 'lucide-react';

export const LanguagesForm = () => {
  const { cvData, updateLanguage, addLanguage, removeLanguage, reorderLanguage } = useCVStore();

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    reorderLanguage(result.source.index, result.destination.index);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center border-b border-slate-200 pb-2">
        <h3 className="text-lg font-semibold text-indigo-900">Diller</h3>
        <button 
          onClick={addLanguage}
          className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 font-medium"
        >
          <Plus size={16} /> Ekle
        </button>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="languages-list">
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
              {cvData.languages.map((lang, index) => (
                <Draggable key={lang.id} draggableId={lang.id} index={index}>
                  {(provided) => (
                    <div 
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className="border border-slate-200 rounded-md p-4 bg-slate-50 relative group flex items-center gap-3"
                    >
                      <div 
                        {...provided.dragHandleProps} 
                        className="text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing"
                      >
                        <GripVertical size={20} />
                      </div>
                      
                      <div className="flex-1 grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-slate-700">Dil</label>
                          <input 
                            type="text" value={lang.name}
                            onChange={(e) => updateLanguage(lang.id, { name: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            placeholder="Örn: İngilizce"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700">Seviye</label>
                          <input 
                            type="text" value={lang.level}
                            onChange={(e) => updateLanguage(lang.id, { level: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            placeholder="Örn: C1 veya Profesyonel"
                          />
                        </div>
                      </div>

                      <button 
                        onClick={() => removeLanguage(lang.id)}
                        className="text-red-400 hover:text-red-600"
                        title="Sil"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
};
