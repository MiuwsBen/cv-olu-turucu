'use client';

import { useCVStore } from '@/store/useCVStore';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import { GripVertical, Plus, Trash2 } from 'lucide-react';

export const ProjectsForm = () => {
  const { cvData, updateProject, addProject, removeProject, reorderProject } = useCVStore();

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    reorderProject(result.source.index, result.destination.index);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center border-b border-slate-200 pb-2">
        <h3 className="text-lg font-semibold text-indigo-900">Projeler</h3>
        <button 
          onClick={addProject}
          className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 font-medium"
        >
          <Plus size={16} /> Ekle
        </button>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="projects-list">
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
              {cvData.projects.map((project, index) => (
                <Draggable key={project.id} draggableId={project.id} index={index}>
                  {(provided) => (
                    <div 
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className="border border-slate-200 rounded-md p-4 bg-slate-50 relative group"
                    >
                      <div 
                        {...provided.dragHandleProps} 
                        className="absolute left-2 top-4 text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing"
                      >
                        <GripVertical size={20} />
                      </div>
                      
                      <button 
                        onClick={() => removeProject(project.id)}
                        className="absolute right-2 top-4 text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Sil"
                      >
                        <Trash2 size={18} />
                      </button>

                      <div className="pl-6 space-y-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-medium text-slate-700">Proje Adı</label>
                            <input 
                              type="text" value={project.name}
                              onChange={(e) => updateProject(project.id, { name: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-700">Kullanılan Teknolojiler (Stack)</label>
                            <input 
                              type="text" value={project.techStack}
                              onChange={(e) => updateProject(project.id, { techStack: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                          <div className="md:col-span-2">
                            <label className="block text-xs font-medium text-slate-700">Projenin Amacı (Kısa özet)</label>
                            <input 
                              type="text" value={project.purpose}
                              onChange={(e) => updateProject(project.id, { purpose: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                          <div className="md:col-span-2">
                            <label className="block text-xs font-medium text-slate-700">Senin Katkın / Zorluk (Challenge)</label>
                            <textarea 
                              value={project.challenge}
                              onChange={(e) => updateProject(project.id, { challenge: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                              rows={2}
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-700">Sistem Mimarisi Notu (Opsiyonel)</label>
                            <input 
                              type="text" value={project.systemDesign || ''}
                              onChange={(e) => updateProject(project.id, { systemDesign: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-700">Ölçeklenebilirlik / Performans (Opsiyonel)</label>
                            <input 
                              type="text" value={project.scalability || ''}
                              onChange={(e) => updateProject(project.id, { scalability: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-700">Canlı Link</label>
                            <input 
                              type="text" value={project.link || ''}
                              onChange={(e) => updateProject(project.id, { link: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-medium text-slate-700">GitHub Repo</label>
                            <input 
                              type="text" value={project.github || ''}
                              onChange={(e) => updateProject(project.id, { github: e.target.value })}
                              className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
};
