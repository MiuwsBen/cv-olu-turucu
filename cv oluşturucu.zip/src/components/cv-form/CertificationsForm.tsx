'use client';

import { useCVStore } from '@/store/useCVStore';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import { GripVertical, Plus, Trash2 } from 'lucide-react';

export const CertificationsForm = () => {
  const { cvData, updateCertification, addCertification, removeCertification, reorderCertification } = useCVStore();

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    reorderCertification(result.source.index, result.destination.index);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center border-b border-slate-200 pb-2">
        <h3 className="text-lg font-semibold text-indigo-900">Sertifikalar</h3>
        <button 
          onClick={addCertification}
          className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 font-medium"
        >
          <Plus size={16} /> Ekle
        </button>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="certifications-list">
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
              {cvData.certifications.map((cert, index) => (
                <Draggable key={cert.id} draggableId={cert.id} index={index}>
                  {(provided) => (
                    <div 
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className="border border-slate-200 rounded-md p-4 bg-slate-50 relative group"
                    >
                      <div 
                        {...provided.dragHandleProps} 
                        className="absolute left-2 top-4 text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing"
                      >
                        <GripVertical size={20} />
                      </div>
                      
                      <button 
                        onClick={() => removeCertification(cert.id)}
                        className="absolute right-2 top-4 text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Sil"
                      >
                        <Trash2 size={18} />
                      </button>

                      <div className="pl-6 grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="md:col-span-2">
                          <label className="block text-xs font-medium text-slate-700">Sertifika Adı</label>
                          <input 
                            type="text" value={cert.name}
                            onChange={(e) => updateCertification(cert.id, { name: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700">Veren Kurum</label>
                          <input 
                            type="text" value={cert.issuer}
                            onChange={(e) => updateCertification(cert.id, { issuer: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700">Tarih</label>
                          <input 
                            type="text" value={cert.date}
                            onChange={(e) => updateCertification(cert.id, { date: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                          />
                        </div>
                        <div className="md:col-span-2">
                          <label className="block text-xs font-medium text-slate-700">Link (Opsiyonel)</label>
                          <input 
                            type="text" value={cert.link || ''}
                            onChange={(e) => updateCertification(cert.id, { link: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
};
