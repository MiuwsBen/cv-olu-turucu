'use client';

import { useCVStore } from '@/store/useCVStore';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import { GripVertical, Plus, Trash2 } from 'lucide-react';

export const SkillsForm = () => {
  const { cvData, updateSkillCategory, addSkillCategory, removeSkillCategory, reorderSkillCategory } = useCVStore();

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    reorderSkillCategory(result.source.index, result.destination.index);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center border-b border-slate-200 pb-2">
        <h3 className="text-lg font-semibold text-indigo-900">Yetenekler</h3>
        <button 
          onClick={addSkillCategory}
          className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 font-medium"
        >
          <Plus size={16} /> Kategori Ekle
        </button>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="skills-list">
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
              {cvData.skills.map((category, index) => (
                <Draggable key={category.id} draggableId={category.id} index={index}>
                  {(provided) => (
                    <div 
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className="border border-slate-200 rounded-md p-4 bg-slate-50 relative group"
                    >
                      <div 
                        {...provided.dragHandleProps} 
                        className="absolute left-2 top-4 text-slate-400 hover:text-slate-600 cursor-grab active:cursor-grabbing"
                      >
                        <GripVertical size={20} />
                      </div>
                      
                      <button 
                        onClick={() => removeSkillCategory(category.id)}
                        className="absolute right-2 top-4 text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Sil"
                      >
                        <Trash2 size={18} />
                      </button>

                      <div className="pl-6 space-y-3">
                        <div>
                          <label className="block text-xs font-medium text-slate-700">Kategori (Örn: Diller, Frameworkler)</label>
                          <input 
                            type="text" value={category.name}
                            onChange={(e) => updateSkillCategory(category.id, { name: e.target.value })}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700">Yetenekler (Virgülle ayırın)</label>
                          <input 
                            type="text" 
                            value={category.skills.join(', ')}
                            onChange={(e) => {
                              const skillsArray = e.target.value.split(',').map(s => s.trim()).filter(s => s !== '');
                              // We only update if the user isn't actively typing a comma (this might be slightly tricky with split, but works for basic cases)
                              // A better UX might be a tag input, but this is simpler and functional.
                              // To avoid losing the trailing comma while typing, we just store the raw string in local state usually, 
                              // but here we can just join and split. Let's improve the onChange to handle it gracefully if needed, 
                              // or just accept they type commas.
                              updateSkillCategory(category.id, { skills: e.target.value.split(',').map(s => s.trim()) });
                            }}
                            className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-1.5 border"
                            placeholder="Örn: React, Next.js, Node.js"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
};
