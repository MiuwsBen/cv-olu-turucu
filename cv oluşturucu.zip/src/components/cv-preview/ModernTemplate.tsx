import React from 'react';
import { useCVStore } from '@/store/useCVStore';

export const ModernTemplate = ({ innerRef }: { innerRef: React.RefObject<HTMLDivElement | null> }) => {
  const { cvData } = useCVStore();
  const { personalInfo, summary, experience, education, skills, projects, languages, certifications } = cvData;

  const contactItems = [
    personalInfo.email,
    personalInfo.phone,
    personalInfo.location,
    personalInfo.linkedin && personalInfo.linkedin.replace('linkedin.com/in/', '').replace(/\/$/, ''),
    personalInfo.github && personalInfo.github.replace('github.com/', '').replace(/\/$/, ''),
    personalInfo.website && personalInfo.website.replace(/^https?:\/\//, '').replace(/\/$/, '')
  ].filter(Boolean);

  return (
    <div 
      ref={innerRef} 
      className="bg-white border border-slate-200 min-h-[1056px] w-full max-w-[816px] mx-auto print:border-none print:max-w-none print:min-h-0 flex flex-row"
    >
      {/* Left Column */}
      <div className="w-1/3 bg-slate-100 p-8 print:p-8 flex flex-col gap-6 text-slate-800">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 uppercase mb-1 leading-none">
            {personalInfo.firstName} <br/> {personalInfo.lastName}
          </h1>
          <p className="text-sm font-bold text-indigo-700 mt-2 uppercase tracking-wide">{personalInfo.title}</p>
        </div>

        <div className="space-y-2 text-xs font-medium">
          {contactItems.map((item, i) => (
            <div key={i} className="break-all">{item}</div>
          ))}
          {personalInfo.militaryService && <div>Askerlik: {personalInfo.militaryService}</div>}
          {personalInfo.drivingLicense && <div>Ehliyet: {personalInfo.drivingLicense}</div>}
        </div>

        {skills.length > 0 && (
          <div>
            <h2 className="text-sm font-bold uppercase tracking-widest text-slate-900 border-b-2 border-slate-300 pb-1 mb-3">
              Yetenekler
            </h2>
            <div className="space-y-3">
              {skills.map((category) => (
                <div key={category.id} className="text-xs">
                  <div className="font-bold text-slate-900 mb-0.5">{category.name}</div>
                  <div className="text-slate-600 leading-snug">{category.skills.join(', ')}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {languages.length > 0 && (
          <div>
            <h2 className="text-sm font-bold uppercase tracking-widest text-slate-900 border-b-2 border-slate-300 pb-1 mb-3">
              Diller
            </h2>
            <div className="space-y-2">
              {languages.map((lang) => (
                <div key={lang.id} className="text-xs">
                  <div className="font-bold text-slate-900">{lang.name}</div>
                  <div className="text-slate-600">{lang.level}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {certifications.length > 0 && (
          <div>
            <h2 className="text-sm font-bold uppercase tracking-widest text-slate-900 border-b-2 border-slate-300 pb-1 mb-3">
              Sertifikalar
            </h2>
            <div className="space-y-3">
              {certifications.map((cert) => (
                <div key={cert.id} className="text-xs">
                  <div className="font-bold text-slate-900">{cert.name}</div>
                  <div className="text-slate-600 mt-0.5">{cert.issuer}</div>
                  {cert.date && <div className="text-slate-500 mt-0.5">{cert.date}</div>}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Right Column */}
      <div className="w-2/3 p-8 print:p-8 flex flex-col gap-6">
        {summary && (
          <section>
            <h2 className="text-base font-bold uppercase tracking-widest text-indigo-900 border-b border-indigo-100 pb-1 mb-3">
              Profil Özeti
            </h2>
            <p className="text-sm text-slate-700 leading-snug font-medium">
              {summary}
            </p>
          </section>
        )}

        {experience.length > 0 && (
          <section>
            <h2 className="text-base font-bold uppercase tracking-widest text-indigo-900 border-b border-indigo-100 pb-1 mb-3">
              İş Deneyimi
            </h2>
            <div className="space-y-4">
              {experience.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline mb-0.5">
                    <h3 className="text-sm font-bold text-slate-900">{exp.position}</h3>
                    <span className="text-xs text-slate-500 font-semibold tracking-wide whitespace-nowrap ml-4">
                      {exp.startDate} — {exp.isCurrent ? 'Devam Ediyor' : exp.endDate}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-indigo-700 mb-1.5">
                    {exp.company}{exp.location ? `, ${exp.location}` : ''}
                  </div>
                  {exp.description.length > 0 && exp.description[0] !== '' && (
                    <ul className="list-none space-y-1">
                      {exp.description.map((desc, index) => desc && (
                        <li key={index} className="text-xs text-slate-700 leading-snug border-l-2 border-indigo-200 pl-3">
                          {desc}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {projects.length > 0 && (
          <section>
            <h2 className="text-base font-bold uppercase tracking-widest text-indigo-900 border-b border-indigo-100 pb-1 mb-3">
              Projeler
            </h2>
            <div className="space-y-4">
              {projects.map((project) => (
                <div key={project.id}>
                  <div className="flex justify-between items-baseline mb-0.5">
                    <h3 className="text-sm font-bold text-slate-900">
                      {project.name}
                    </h3>
                  </div>
                  <div className="text-xs font-semibold text-slate-600 mb-1">
                    <span className="text-indigo-700">Teknolojiler:</span> {project.techStack}
                  </div>
                  <div className="text-xs text-slate-700 leading-snug space-y-1 border-l-2 border-indigo-200 pl-3">
                    {project.purpose && <p>{project.purpose}</p>}
                    {project.challenge && <p><span className="font-semibold text-slate-900">Katkı:</span> {project.challenge}</p>}
                    {project.systemDesign && <p><span className="font-semibold text-slate-900">Mimari:</span> {project.systemDesign}</p>}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {education.length > 0 && (
          <section>
            <h2 className="text-base font-bold uppercase tracking-widest text-indigo-900 border-b border-indigo-100 pb-1 mb-3">
              Eğitim
            </h2>
            <div className="space-y-3">
              {education.map((edu) => (
                <div key={edu.id}>
                  <div className="flex justify-between items-baseline mb-0.5">
                    <h3 className="text-sm font-bold text-slate-900">{edu.institution}</h3>
                    <span className="text-xs text-slate-500 font-semibold tracking-wide whitespace-nowrap ml-4">
                      {edu.startDate} — {edu.isCurrent ? 'Devam Ediyor' : edu.endDate}
                    </span>
                  </div>
                  <div className="text-xs font-medium text-slate-700">
                    {edu.degree} - {edu.field} {edu.gpa && <span className="font-bold text-indigo-700 ml-2">GPA: {edu.gpa}</span>}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};
