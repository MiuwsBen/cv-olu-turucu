export interface PersonalInfo {
  firstName: string;
  lastName: string;
  title: string;
  email: string;
  phone: string;
  location: string;
  website?: string;
  github?: string;
  linkedin?: string;
  militaryService?: string;
  drivingLicense?: string;
}

export interface Experience {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
  location?: string;
  description: string[]; // Bullet points (XYZ formula)
}

export interface Education {
  id: string;
  institution: string;
  degree: string;
  field: string;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
  gpa?: string;
  details?: string;
}

export interface SkillCategory {
  id: string;
  name: string; // e.g., 'Languages', 'Frameworks', 'Tools'
  skills: string[];
}

export interface Project {
  id: string;
  name: string;
  purpose: string;
  techStack: string;
  challenge: string;
  systemDesign?: string;
  scalability?: string;
  link?: string;
  github?: string;
}

export interface Language {
  id: string;
  name: string;
  level: string;
}

export interface Certification {
  id: string;
  name: string;
  issuer: string;
  date: string;
  link?: string;
}

export interface CVData {
  personalInfo: PersonalInfo;
  summary: string;
  experience: Experience[];
  education: Education[];
  skills: SkillCategory[];
  projects: Project[];
  languages: Language[];
  certifications: Certification[];
}
